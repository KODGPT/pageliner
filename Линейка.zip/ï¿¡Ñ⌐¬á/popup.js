const addHorizontalBtn = document.getElementById('add-horizontal');
const addVerticalBtn = document.getElementById('add-vertical');
const clearBtn = document.getElementById('clear-lines');
const colorButton = document.getElementById('color-button');
const colorPicker = document.getElementById('line-color');
const toggleActiveBtn = document.getElementById('toggle-active');

function sendMessage(message) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    console.log('Active tabs:', tabs);
    if (!tabs.length) return;
    chrome.tabs.sendMessage(tabs[0].id, message).catch(err => {
      console.warn('sendMessage error:', err.message);
    });
  });
}

chrome.storage.local.get(['lineColor', 'isActive'], (result) => {
  const color = result.lineColor || '#ff0000';
  const isActive = result.isActive !== false;
  colorPicker.value = color;
  updateColorButton(color);
  toggleActiveBtn.textContent = isActive ? 'Выключить линейку' : 'Включить линейку';
  updateButtonStates(isActive);
  if (isActive) {
    sendMessage({ type: 'changeColor', color });
  }
});

function updateColorButton(color) {
  colorButton.style.backgroundColor = color;
  const c = color.substring(1);
  const rgb = parseInt(c, 16);
  const r = (rgb >> 16) & 0xff;
  const g = (rgb >> 8) & 0xff;
  const b = (rgb) & 0xff;
  const brightness = (r * 299 + g * 587 + b * 114) / 1000;
  colorButton.style.color = brightness > 125 ? 'black' : 'white';
}

function updateButtonStates(isActive) {
  addHorizontalBtn.disabled = !isActive;
  addVerticalBtn.disabled = !isActive;
  clearBtn.disabled = !isActive;
  colorButton.disabled = !isActive;
}

toggleActiveBtn.addEventListener('click', () => {
  chrome.storage.local.get(['isActive'], (result) => {
    const isActive = result.isActive !== false;
    const newState = !isActive;
    chrome.storage.local.set({ isActive: newState }, () => {
      toggleActiveBtn.textContent = newState ? 'Выключить линейку' : 'Включить линейку';
      updateButtonStates(newState);
      sendMessage({ type: newState ? 'enableExtension' : 'disableExtension' });
    });
  });
});

colorButton.addEventListener('click', () => {
  colorPicker.click();
});

colorPicker.addEventListener('input', () => {
  const color = colorPicker.value;
  updateColorButton(color);
  chrome.storage.local.set({ lineColor: color });
  sendMessage({ type: 'changeColor', color });
});

addHorizontalBtn.addEventListener('click', () => {
  chrome.storage.local.get(['isActive'], (result) => {
    if (result.isActive !== false) {
      sendMessage({ type: 'addLine', direction: 'horizontal' });
    }
  });
});

addVerticalBtn.addEventListener('click', () => {
  chrome.storage.local.get(['isActive'], (result) => {
    if (result.isActive !== false) {
      sendMessage({ type: 'addLine', direction: 'vertical' });
    }
  });
});

clearBtn.addEventListener('click', () => {
  chrome.storage.local.get(['isActive'], (result) => {
    if (result.isActive !== false) {
      sendMessage({ type: 'clearLines' });
    }
  });
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'syncColor') {
    colorPicker.value = message.color;
    updateColorButton(message.color);
  }
});