chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install' || details.reason === 'update') {
    chrome.storage.local.set({ isActive: false }, () => {
      console.log('Extension installed or updated, set isActive to false');
    });
  }
});

let lastDomain = null;

function getDomain(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return null;
  }
}

function isValidUrl(url) {
  return url && !url.startsWith('chrome://') && !url.startsWith('chrome-extension://') && !url.startsWith('file://');
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && isValidUrl(tab.url)) {
    const domain = getDomain(tab.url);
    if (domain === 'example.com') {
      chrome.tabs.sendMessage(tabId, { type: 'disableExtension' }).catch(err => {
        console.warn('sendMessage error (onUpdated):', err.message);
      });
    } else if (domain !== lastDomain) {
      lastDomain = domain;
      chrome.tabs.sendMessage(tabId, { type: 'clearLines' }).catch(err => {
        console.warn('sendMessage error (onUpdated):', err.message);
      });
    }
  }
});

chrome.tabs.onActivated.addListener(activeInfo => {
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (tab && isValidUrl(tab.url)) {
      const domain = getDomain(tab.url);
      if (domain !== lastDomain) {
        lastDomain = domain;
        chrome.tabs.sendMessage(activeInfo.tabId, { type: 'clearLines' }).catch(err => {
          console.warn('sendMessage error (onActivated):', err.message);
        });
      }
    }
  });
});