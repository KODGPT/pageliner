console.log('content.js loaded');

let style = null;
let lineContainer = null;
const lines = [];
const distanceLabels = new Map();
let currentColor = '#ff0000';

// Регистрируем слушатель сообщений всегда
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Received message:', message);
  if (message.type === 'disableExtension') {
    removeExtensionElements();
    chrome.storage.local.set({ isActive: false });
    return;
  }
  if (message.type === 'enableExtension') {
    chrome.storage.local.set({ isActive: true }, () => {
      initializeExtension();
    });
    return;
  }
  if (message.type === 'addLine') {
    chrome.storage.local.get(['isActive'], (result) => {
      if (result.isActive !== false) {
        createLine(message.direction);
      }
    });
  } else if (message.type === 'clearLines') {
    chrome.storage.local.get(['isActive'], (result) => {
      if (result.isActive !== false) {
        clearAllLines();
      }
    });
  } else if (message.type === 'changeColor') {
    chrome.storage.local.get(['isActive'], (result) => {
      if (result.isActive !== false) {
        currentColor = message.color;
        updateLineColors();
        saveLines();
      }
    });
  } else if (message.type === 'syncColor') {
    currentColor = message.color;
    updateLineColors();
  }
});

function initializeExtension() {
  // Проверяем, не инициализировано ли уже
  if (style && style.parentNode && lineContainer && lineContainer.parentNode) return;

  // Создаем стили
  style = document.createElement('style');
  style.textContent = `
    #line-container {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 9999;
      display: none;
    }
    .line-wrapper {
      pointer-events: auto;
      position: absolute;
      cursor: move;
    }
    .line {
      position: absolute;
    }
    .distance-label {
      position: fixed;
      background: rgba(0,0,0,0.7);
      color: white;
      font-size: 12px;
      padding: 2px 5px;
      border-radius: 3px;
      pointer-events: none;
      z-index: 10000;
      user-select: none;
    }
  `;
  document.head.appendChild(style);

  // Создаем контейнер для линий
  lineContainer = document.createElement('div');
  lineContainer.id = 'line-container';
  document.body.appendChild(lineContainer);

  // Загружаем сохраненные линии
  loadLines();
}

function createLine(direction, position = null) {
  if (!lineContainer || !lineContainer.parentNode) {
    // Если контейнер был удален, создаем новый
    lineContainer = document.createElement('div');
    lineContainer.id = 'line-container';
    document.body.appendChild(lineContainer);
  }
  lineContainer.style.display = 'block';

  const wrapper = document.createElement('div');
  wrapper.classList.add('line-wrapper', direction);

  const line = document.createElement('div');
  line.classList.add('line', direction);

  wrapper.appendChild(line);
  lineContainer.appendChild(wrapper);

  wrapper.style.zIndex = '9999';
  wrapper.style.pointerEvents = 'auto';

  if (direction === 'vertical') {
    wrapper.style.width = '10px';
    wrapper.style.height = '100%';
    wrapper.style.left = position !== null ? `${position}px` : '100px';
    wrapper.style.top = '0';
    line.style.width = '1px';
    line.style.height = '100%';
    line.style.left = '4.5px';
    line.style.top = '0';
  } else {
    wrapper.style.height = '10px';
    wrapper.style.width = '100%';
    wrapper.style.top = position !== null ? `${position}px` : '100px';
    wrapper.style.left = '0';
    line.style.height = '1px';
    line.style.width = '100%';
    line.style.top = '4.5px';
    line.style.left = '0';
  }

  line.style.background = currentColor;

  const current = { wrapper, direction, line };
  lines.push(current);

  wrapper.addEventListener('mousedown', (e) => {
    e.preventDefault();
    const move = (ev) => {
      if (direction === 'vertical') {
        wrapper.style.left = `${ev.clientX - 5}px`;
      } else {
        wrapper.style.top = `${ev.clientY - 5}px`;
      }
      updateDistances();
    };

    const up = () => {
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', up);
      updateDistances();
      saveLines();
    };

    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
  });

  updateDistances();
  updateLineColors();
  saveLines();
}

function updateLineColors() {
  lines.forEach(({ line }) => {
    if (line && line.parentNode) {
      line.style.background = currentColor;
    }
  });
}

function updateDistances() {
  const toRemove = new Set(distanceLabels.keys());

  // Проверяем, что есть хотя бы две линии одного типа
  for (let i = 0; i < lines.length; i++) {
    for (let j = i + 1; j < lines.length; j++) {
      if (lines[i].direction !== lines[j].direction) continue;

      const lineA = lines[i];
      const lineB = lines[j];

      // Проверяем, что элементы все еще в DOM
      if (!lineA.wrapper.parentNode || !lineB.wrapper.parentNode) continue;

      const posA = getLineCoord(lineA);
      const posB = getLineCoord(lineB);

      // Проверяем, что координаты валидны
      if (isNaN(posA) || isNaN(posB)) continue;

      const distance = Math.abs(posA - posB);

      const key = `${i}-${j}`;
      toRemove.delete(key);

      let label = distanceLabels.get(key);
      if (!label) {
        label = document.createElement('div');
        label.classList.add('distance-label');
        document.body.appendChild(label);
        distanceLabels.set(key, label);
      }

      label.textContent = `${distance}px`;
      label.style.display = 'block';

      if (lineA.direction === 'vertical') {
        const left = Math.min(posA, posB) + distance / 2;
        label.style.left = `${left}px`;
        label.style.top = '10px';
      } else {
        const top = Math.min(posA, posB) + distance / 2;
        label.style.top = `${top}px`;
        label.style.left = '10px';
      }
    }
  }

  // Удаляем ненужные метки
  toRemove.forEach(key => {
    const label = distanceLabels.get(key);
    if (label && label.parentNode) {
      label.remove();
      distanceLabels.delete(key);
    }
  });
}

function getLineCoord(line) {
  if (!line.wrapper || !line.wrapper.parentNode) return NaN;
  const style = window.getComputedStyle(line.wrapper);
  if (line.direction === 'vertical') {
    return parseFloat(style.left) + 5;
  } else {
    return parseFloat(style.top) + 5;
  }
}

function saveLines() {
  const savedLines = lines
    .filter(line => line.wrapper && line.wrapper.parentNode) // Сохраняем только линии в DOM
    .map(({ wrapper, direction }) => {
      if (direction === 'vertical') {
        return { direction, position: parseFloat(wrapper.style.left) };
      } else {
        return { direction, position: parseFloat(wrapper.style.top) };
      }
    });
  chrome.storage.local.set({ savedLines, lineColor: currentColor });
}

function loadLines() {
  chrome.storage.local.get(['savedLines', 'lineColor'], (result) => {
    if (result.lineColor) {
      currentColor = result.lineColor;
      updateLineColors();
      chrome.runtime.sendMessage({ type: 'syncColor', color: currentColor });
    }
    if (Array.isArray(result.savedLines)) {
      result.savedLines.forEach(({ direction, position }) => {
        if (!isNaN(position)) {
          createLine(direction, position);
        }
      });
    }
  });
}

function clearAllLines() {
  if (lineContainer) {
    lineContainer.innerHTML = '';
    lineContainer.style.display = 'none';
  }
  lines.length = 0;
  distanceLabels.forEach(label => {
    if (label && label.parentNode) label.remove();
  });
  distanceLabels.clear();
  chrome.storage.local.remove('savedLines');
}

function removeExtensionElements() {
  if (lineContainer && lineContainer.parentNode) {
    lineContainer.remove();
    lineContainer = null;
  }
  if (style && style.parentNode) {
    style.remove();
    style = null;
  }
  distanceLabels.forEach(label => {
    if (label && label.parentNode) label.remove();
  });
  distanceLabels.clear();
  lines.length = 0;
}

chrome.storage.local.get(['isActive'], (result) => {
  if (result.isActive !== false) {
    initializeExtension();
  }
});